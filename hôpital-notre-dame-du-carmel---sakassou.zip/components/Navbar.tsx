
import React from 'react';
import { Page } from '../types';
import { translations } from '../translations';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  lang: 'fr' | 'en';
  setLang: (lang: 'fr' | 'en') => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate, lang }) => {
  const t = translations[lang].nav;

  // Configuration des onglets mobiles avec icônes
  const mobileTabs = [
    { label: t.home, id: Page.Home, icon: '🏠' },
    { label: t.services, id: Page.Services, icon: '🏥' },
    { label: t.booking, id: Page.Booking, icon: '📅' },
    { label: t.portal, id: Page.PatientPortal, icon: '👤' },
  ];

  const desktopNavItems = [
    { label: t.home, id: Page.Home },
    { label: t.about, id: Page.About },
    { label: t.disease, id: Page.DiseaseInfo },
    { label: t.services, id: Page.Services },
    { label: t.booking, id: Page.Booking },
  ];

  return (
    <>
      {/* Header Desktop & Mobile Top Bar */}
      <nav className="bg-white shadow-sm sticky top-0 z-40 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            {/* Logo */}
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => onNavigate(Page.Home)}>
              <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-inner">
                <span className="relative">
                  †
                  <span className="absolute -top-1 -right-2 text-[10px] text-green-300">🌿</span>
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-emerald-900 font-bold leading-tight text-sm sm:text-base">Notre-Dame du Carmel</span>
                <span className="text-gray-400 text-[9px] uppercase tracking-wider font-bold">Sakassou • Gbêkê</span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-6">
              {desktopNavItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`text-sm font-semibold transition-all px-2 py-1 rounded-lg ${
                    currentPage === item.id ? 'text-emerald-600 bg-emerald-50' : 'text-gray-500 hover:text-emerald-500 hover:bg-gray-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="h-6 w-px bg-gray-200 mx-2"></div>
              <button 
                onClick={() => onNavigate(Page.StaffPortal)}
                className="text-gray-400 hover:text-emerald-600 text-[10px] font-black uppercase tracking-tighter transition-all"
              >
                🔒 {t.staff}
              </button>
              <button 
                onClick={() => onNavigate(Page.PatientPortal)}
                className="bg-emerald-600 text-white px-5 py-2.5 rounded-full text-sm font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-900/10 active:scale-95"
              >
                {t.portal}
              </button>
            </div>

            {/* Mobile Top Actions (Language/Staff) */}
            <div className="lg:hidden flex items-center gap-3">
               <button 
                 onClick={() => onNavigate(Page.StaffPortal)}
                 className={`p-2 rounded-xl border ${currentPage === Page.StaffPortal ? 'bg-emerald-900 text-white border-emerald-900' : 'bg-gray-50 text-gray-400 border-gray-100'}`}
               >
                 <span className="text-lg">🔒</span>
               </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Tab Bar (Fixed) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-100 z-50 pb-safe shadow-[0_-10px_30px_rgba(0,0,0,0.05)]">
        <div className="flex justify-around items-end h-18 px-2 py-3">
          {mobileTabs.map((tab) => {
            const isActive = currentPage === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onNavigate(tab.id)}
                className="relative flex flex-col items-center gap-1 group w-1/4"
              >
                {/* Animation pill for active tab */}
                <div className={`flex flex-col items-center transition-all duration-300 ${isActive ? '-translate-y-1' : ''}`}>
                  <div className={`w-12 h-8 rounded-2xl flex items-center justify-center transition-all ${isActive ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' : 'text-gray-400'}`}>
                    <span className="text-xl">{tab.icon}</span>
                  </div>
                  <span className={`text-[9px] font-black uppercase tracking-tighter mt-1 transition-colors ${isActive ? 'text-emerald-700' : 'text-gray-400'}`}>
                    {tab.label}
                  </span>
                </div>
                {isActive && (
                  <div className="absolute -bottom-1 w-1 h-1 bg-emerald-600 rounded-full animate-pulse"></div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Navbar;
