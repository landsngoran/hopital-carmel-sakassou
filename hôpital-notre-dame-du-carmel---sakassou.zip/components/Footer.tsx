
import React from 'react';
import { Page } from '../types';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-emerald-950 text-emerald-100 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-4 gap-12 border-b border-white/10 pb-16">
        <div className="col-span-1 md:col-span-1">
          <div className="flex items-center space-x-2 mb-6">
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-emerald-900 font-bold text-lg">
              †
            </div>
            <span className="text-white font-bold text-xl">ND du Carmel</span>
          </div>
          <p className="text-sm text-emerald-300 leading-relaxed mb-6 italic">
            "Soigner le corps, apaiser l'âme." Missionnaire et dévoué à la santé communautaire en Côte d'Ivoire.
          </p>
          <div className="flex gap-4">
            <span className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer transition-all">f</span>
            <span className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer transition-all">x</span>
            <span className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 cursor-pointer transition-all">in</span>
          </div>
        </div>

        <div>
          <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-xs">Accès Rapide</h4>
          <ul className="space-y-3 text-sm">
            <li><button onClick={() => onNavigate(Page.About)} className="hover:text-white transition-colors">Notre Mission</button></li>
            <li><button onClick={() => onNavigate(Page.Services)} className="hover:text-white transition-colors">Nos Services</button></li>
            <li><button onClick={() => onNavigate(Page.Booking)} className="hover:text-white transition-colors">Prendre RDV</button></li>
            <li><button onClick={() => onNavigate(Page.PatientPortal)} className="hover:text-white transition-colors">Dossier Patient</button></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-xs">Contact Sakassou</h4>
          <ul className="space-y-4 text-sm">
            <li className="flex items-start gap-3">
              <span className="text-emerald-400">📍</span>
              <span>Quartier Hospitalier, Sakassou, Région de Gbêkê (Route Yamoussoukro)</span>
            </li>
            <li className="flex items-center gap-3">
              <span className="text-emerald-400">📞</span>
              <span>+225 21 01 02 03</span>
            </li>
            <li className="flex items-center gap-3">
              <span className="text-emerald-400">📧</span>
              <span>contact@nd-carmel-sakassou.ci</span>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-xs">Localisation</h4>
          <div className="rounded-2xl overflow-hidden h-32 grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all border border-white/10">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31671.218556813478!2d-5.289133!3d7.458909!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfb993309a4897f7%3A0x6b4f7e53f064f27d!2sSakassou!5e0!3m2!1sfr!2sci!4v1710000000000!5m2!1sfr!2sci" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              loading="lazy"
            ></iframe>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-8 flex flex-col md:flex-row justify-between items-center text-[10px] text-emerald-500 uppercase font-bold tracking-widest">
        <span>© 2024 Hôpital Notre-Dame du Carmel - Sakassou</span>
        <div className="flex gap-6 mt-4 md:mt-0">
          <a href="#" className="hover:text-white">Mentions Légales (CNDP)</a>
          <a href="#" className="hover:text-white">Confidentialité RGPD</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
