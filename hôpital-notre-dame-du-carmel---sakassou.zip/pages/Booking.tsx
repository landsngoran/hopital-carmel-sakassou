
import React, { useState, useRef, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface FormState {
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
}

const Booking: React.FC = () => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<FormState>({
    name: '',
    phone: '',
    email: '',
    subject: '',
    message: ''
  });

  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const [errors, setErrors] = useState<Partial<FormState>>({});

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => audioChunksRef.current.push(e.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioURL(URL.createObjectURL(blob));
      };
      mediaRecorder.start();
      setIsRecording(true);
      timerRef.current = window.setInterval(() => setRecordingTime(p => p + 1), 1000);
    } catch (e) { alert("Microphone requis."); }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const validate = () => {
    const e: Partial<FormState> = {};
    if (!formData.name) e.name = "Nom requis";
    if (!formData.phone) e.phone = "Téléphone requis";
    if (!formData.subject) e.subject = "Objet requis";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    
    await supabase.from('booking_messages').insert({
      ...formData,
      audio: audioURL,
      status: 'NOUVEAU',
      date: new Date().toLocaleDateString('fr-FR')
    });

    setIsSubmitting(false);
    setStep(2);
  };

  return (
    <div className="animate-fadeIn py-16 px-4 bg-gray-50/50">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-emerald-900 mb-4 font-serif">Contact & RDV</h1>
          <p className="text-gray-600 italic uppercase tracking-widest text-[10px] font-black">Prenez rendez-vous ou laissez-nous un message vocal.</p>
        </div>

        <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-emerald-900/10 overflow-hidden border border-emerald-50">
          {step === 1 ? (
            <form onSubmit={handleSubmit} className="p-8 md:p-12 space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <input type="text" placeholder="Nom Complet" className="w-full px-5 py-4 rounded-2xl bg-gray-50 border border-gray-100" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                <input type="tel" placeholder="+225 Téléphone" className="w-full px-5 py-4 rounded-2xl bg-gray-50 border border-gray-100" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
              </div>
              <select className="w-full px-5 py-4 rounded-2xl bg-gray-50 border border-gray-100" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})}>
                <option value="">Motif du rendez-vous</option>
                <option value="Consultation">Consultation Buruli</option>
                <option value="Urgence">Urgence Immédiate</option>
                <option value="Gynéco">Maternité</option>
              </select>
              <textarea rows={4} placeholder="Votre message..." className="w-full px-5 py-4 rounded-2xl bg-gray-50 border border-gray-100 resize-none" value={formData.message} onChange={e => setFormData({...formData, message: e.target.value})} />
              
              <div className="p-6 bg-emerald-50 rounded-3xl text-center border-2 border-dashed border-emerald-100">
                {!isRecording && !audioURL && <button type="button" onClick={startRecording} className="text-emerald-600 font-black text-[10px] uppercase">🎤 Enregistrer un message vocal</button>}
                {isRecording && <button type="button" onClick={stopRecording} className="text-red-600 font-black animate-pulse">🛑 ARRÊTER ({recordingTime}s)</button>}
                {audioURL && <p className="text-emerald-600 font-bold text-xs">Audio capturé ✓</p>}
              </div>

              <button type="submit" disabled={isSubmitting} className="w-full bg-emerald-900 text-white py-6 rounded-2xl font-bold uppercase tracking-widest">
                {isSubmitting ? "Envoi..." : "Envoyer ma demande"}
              </button>
            </form>
          ) : (
            <div className="p-16 text-center animate-fadeIn">
              <h2 className="text-3xl font-serif italic text-emerald-900 mb-4">Demande Transmise</h2>
              <p className="text-gray-500 italic mb-8">Un médecin examinera votre dossier sous peu.</p>
              <button onClick={() => setStep(1)} className="bg-emerald-900 text-white px-8 py-3 rounded-full font-bold">Retour</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Booking;
