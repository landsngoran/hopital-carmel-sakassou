
import React, { useState, useEffect, useRef } from 'react';
import { StaffRole } from '../types';
import { supabase } from '../lib/supabase';

enum ViewMode { Login, Register, Dashboard, HIVUnit, Pharmacy, Inbox, SyncCenter, Settings }

interface StaffProfile {
  id: string; name: string; role: StaffRole; points: number; status: 'ACTIF' | 'ATTENTE';
}

interface ViralLoad {
  patient_id: string;
  date: string;
  value: number;
  unit: string;
  status: 'HAUT' | 'INDÉTECTABLE' | 'NORMAL';
}

interface RoleConfig {
  label: string;
  color: string;
  icon: string;
  bg: string;
  lightBg: string;
}

const DEFAULT_ROLE_THEMES: Record<string, RoleConfig> = {
  'SPECIALIST': { label: 'Médecin Spécialiste', color: 'text-blue-600', icon: '🩺', bg: 'bg-blue-600', lightBg: 'bg-blue-50' },
  'SURGERY': { label: 'Chirurgie', color: 'text-orange-600', icon: '🩹', bg: 'bg-orange-600', lightBg: 'bg-orange-50' },
  'HIV': { label: 'Unité VIH/ARV', color: 'text-red-600', icon: '🎗️', bg: 'bg-red-600', lightBg: 'bg-red-50' },
  'ADMIN': { label: 'Service Informatique', color: 'text-black', icon: '💻', bg: 'bg-gray-900', lightBg: 'bg-gray-100' },
  'IDE': { label: 'Infirmier (IDE)', color: 'text-emerald-600', icon: '💉', bg: 'bg-emerald-600', lightBg: 'bg-emerald-50' },
  'GYNECO': { label: 'Maternité', color: 'text-pink-600', icon: '🤰', bg: 'bg-pink-600', lightBg: 'bg-pink-50' },
  'LAB': { label: 'Laboratoire', color: 'text-purple-600', icon: '🔬', bg: 'bg-purple-600', lightBg: 'bg-purple-50' },
  'DATA': { label: 'Gestion Données', color: 'text-emerald-900', icon: '📊', bg: 'bg-emerald-900', lightBg: 'bg-emerald-50' },
};

const StaffPortal: React.FC = () => {
  const [view, setView] = useState<ViewMode>(ViewMode.Login);
  const [staffId, setStaffId] = useState('');
  const [currentUser, setCurrentUser] = useState<StaffProfile | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [syncStatus, setSyncStatus] = useState<'IDLE' | 'SYNCING' | 'DONE'>('IDLE');
  const [roleThemes, setRoleThemes] = useState<Record<string, RoleConfig>>(DEFAULT_ROLE_THEMES);
  const [viralHistory, setViralHistory] = useState<ViralLoad[]>([]);
  
  // États Saisie VIH Innovante
  const [isDictating, setIsDictating] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [newEntry, setNewEntry] = useState<Partial<ViralLoad>>({ patient_id: 'ND-', value: 0, unit: 'copies/ml' });

  // Inscription States (Dossier d'embauche numérique)
  const [regName, setRegName] = useState('');
  const [regRole, setRegRole] = useState<StaffRole>('SPECIALIST');
  const [serviceCode, setServiceCode] = useState('');
  const [healthStatus, setHealthStatus] = useState({ vax: false, medicalVisit: false });
  const [ethicsSigned, setEthicsSigned] = useState(false);
  const [diplomaVerified, setDiplomaVerified] = useState<'NONE' | 'PENDING' | 'VERIFIED'>('NONE');

  useEffect(() => {
    const savedThemes = localStorage.getItem('carmel_role_themes');
    if (savedThemes) setRoleThemes(JSON.parse(savedThemes));
    loadViralHistory();
  }, []);

  const loadViralHistory = () => {
    supabase.from('viral_load_tracking').select().then(({ data }: any) => {
      setViralHistory(data || []);
    });
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    supabase.from('staff_profiles').eq('id', staffId.toUpperCase()).then(({ data }: any) => {
      if (data.length > 0) {
        setCurrentUser(data[0]);
        setView(ViewMode.Dashboard);
        loadData();
      } else alert("Matricule non reconnu.");
    });
  };

  const loadData = () => {
    supabase.from('booking_messages').select().then(({ data }: any) => setMessages(data));
  };

  const handleSync = async () => {
    setSyncStatus('SYNCING');
    setTimeout(() => {
      setSyncStatus('DONE');
      setTimeout(() => setSyncStatus('IDLE'), 3000);
    }, 2500);
  };

  const simulateDiplomaVerify = () => {
    setDiplomaVerified('PENDING');
    setTimeout(() => setDiplomaVerified('VERIFIED'), 2000);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!healthStatus.vax || !ethicsSigned || diplomaVerified !== 'VERIFIED') {
      alert("Le dossier est incomplet (Vérification diplôme, Vaccination ou Éthique manquante).");
      return;
    }
    const serviceName = supabase.verifySiloCode(serviceCode);
    if (!serviceName) return alert("Code d'accréditation (OTP RH) invalide.");
    
    const newId = `SAK-${regRole}-${Math.floor(Math.random()*900)}`;
    await supabase.from('staff_profiles').insert({ 
      id: newId, 
      name: regName, 
      role: regRole, 
      status: 'ACTIF', 
      points: 100 
    });
    alert(`Dossier validé ! Votre matricule de service est : ${newId}`);
    setView(ViewMode.Login);
  };

  const startDictation = () => {
    setIsDictating(true);
    setTimeout(() => {
      setNewEntry({ patient_id: 'ND-2055', value: 45, unit: 'copies/ml' });
      setIsDictating(false);
    }, 3000);
  };

  const handleImportExcel = () => {
    setIsImporting(true);
    setTimeout(() => {
      setIsImporting(false);
      alert("Importation réussie : 12 nouveaux rapports synchronisés.");
      loadViralHistory();
    }, 2000);
  };

  const addViralEntry = async () => {
    const status = newEntry.value! > 1000 ? 'HAUT' : newEntry.value! < 50 ? 'INDÉTECTABLE' : 'NORMAL';
    const record = { ...newEntry, date: new Date().toISOString().split('T')[0], status };
    await supabase.from('viral_load_tracking').insert(record);
    setNewEntry({ patient_id: 'ND-', value: 0, unit: 'copies/ml' });
    loadViralHistory();
  };

  if (view === ViewMode.Login) {
    return (
      <div className="min-h-screen bg-[#064e3b] flex items-center justify-center p-6 animate-fadeIn">
        <div className="bg-white p-12 rounded-[3.5rem] shadow-2xl w-full max-w-md text-center border-t-8 border-blue-600">
          <div className="w-20 h-20 bg-[#2563eb] text-white rounded-3xl mx-auto mb-8 flex items-center justify-center text-4xl font-bold shadow-lg shadow-blue-500/20">†</div>
          <h2 className="text-3xl font-serif italic mb-2">Carmel OS</h2>
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-10">Accès Personnel Hospitalier</p>
          <form onSubmit={handleLogin} className="space-y-4">
            <input type="text" placeholder="MATRICULE" className="w-full px-8 py-6 rounded-[2rem] bg-gray-50 border-none text-center font-black uppercase outline-none focus:ring-2 focus:ring-blue-500 shadow-inner" value={staffId} onChange={e => setStaffId(e.target.value)} />
            <button type="submit" className="w-full bg-[#2563eb] text-white py-6 rounded-[2rem] font-black uppercase shadow-xl hover:scale-[1.02] transition-all">Connexion</button>
          </form>
          <button onClick={() => setView(ViewMode.Register)} className="mt-8 text-[10px] font-black text-blue-600 uppercase tracking-widest underline decoration-2 underline-offset-4">Demander un enrôlement</button>
        </div>
      </div>
    );
  }

  if (view === ViewMode.Register) {
    return (
      <div className="min-h-screen bg-[#064e3b] flex items-center justify-center p-6 animate-fadeIn">
        <div className="bg-white rounded-[4rem] shadow-2xl w-full max-w-7xl flex flex-col lg:flex-row overflow-hidden min-h-[850px]">
           {/* Sidebar: Prévisualisation du Badge */}
           <div className="lg:w-1/3 bg-blue-600 p-12 flex flex-col items-center justify-center text-white relative">
              <div className="absolute top-8 left-8 text-[10px] font-black opacity-40 uppercase tracking-[0.3em]">Badge Virtuel</div>
              <div className="bg-white rounded-[2.5rem] w-full max-w-[280px] p-8 shadow-2xl text-gray-900 transform -rotate-2 hover:rotate-0 transition-transform duration-500">
                 <div className="w-full aspect-square bg-gray-100 rounded-3xl mb-6 flex items-center justify-center text-7xl shadow-inner">
                    {roleThemes[regRole]?.icon || "👤"}
                 </div>
                 <div className="text-center">
                    <h4 className="text-lg font-black uppercase leading-tight mb-1">{regName || "NOUVEAU MEMBRE"}</h4>
                    <p className={`text-[10px] font-bold uppercase tracking-widest ${roleThemes[regRole]?.color || 'text-blue-600'}`}>
                       {roleThemes[regRole]?.label}
                    </p>
                    <div className="mt-6 flex justify-center gap-1">
                       <div className="w-1 h-1 bg-gray-200 rounded-full"></div>
                       <div className="w-8 h-1 bg-gray-200 rounded-full"></div>
                       <div className="w-1 h-1 bg-gray-200 rounded-full"></div>
                    </div>
                    <div className="mt-4 flex items-center justify-center gap-2">
                       <div className={`w-2 h-2 rounded-full ${diplomaVerified === 'VERIFIED' ? 'bg-green-500' : 'bg-gray-200 animate-pulse'}`}></div>
                       <span className="text-[8px] font-black text-gray-400 uppercase">Accréditation Cloud</span>
                    </div>
                 </div>
              </div>
              <div className="mt-12 text-center space-y-4 max-w-xs">
                 <p className="text-sm italic opacity-70">"Soigner le corps, apaiser l'âme. Ce badge est le symbole de votre engagement envers les patients de Sakassou."</p>
              </div>
           </div>

           {/* Formulaire complet d'embauche */}
           <div className="flex-grow p-12 lg:p-20 overflow-y-auto">
              <div className="mb-12">
                <h2 className="text-4xl font-serif italic text-emerald-950 mb-2">Dossier d'Embauche Digital</h2>
                <div className="w-20 h-1 bg-orange-500 rounded-full"></div>
              </div>

              <form onSubmit={handleRegister} className="space-y-12">
                 {/* Section Identity */}
                 <div className="grid md:grid-cols-2 gap-10">
                    <div className="space-y-4">
                       <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Nom et Prénoms</label>
                       <input type="text" required placeholder="Ex: Koffi Amoin Marie" className="w-full px-8 py-5 rounded-2xl bg-gray-50 border-none font-bold text-gray-800 focus:ring-2 focus:ring-blue-100" value={regName} onChange={e => setRegName(e.target.value)} />
                    </div>
                    <div className="space-y-4">
                       <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Poste & Accréditation</label>
                       <select className="w-full px-8 py-5 rounded-2xl bg-gray-50 border-none font-bold text-gray-800" value={regRole} onChange={e => setRegRole(e.target.value as StaffRole)}>
                          {(Object.entries(roleThemes) as [string, RoleConfig][]).map(([k, v]) => <option key={k} value={k}>{v.icon} {v.label}</option>)}
                       </select>
                    </div>
                 </div>

                 {/* Section: Certification & Cloud verify */}
                 <div className="bg-gray-50 p-8 rounded-[2.5rem] border border-gray-100">
                    <h3 className="text-xs font-black uppercase text-emerald-800 mb-6 tracking-widest flex items-center gap-3">
                       <span className="w-6 h-6 bg-emerald-100 rounded flex items-center justify-center text-[10px]">01</span>
                       Vérification de Diplôme
                    </h3>
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${diplomaVerified === 'VERIFIED' ? 'bg-green-100 text-green-600' : 'bg-white text-gray-400'}`}>
                             {diplomaVerified === 'VERIFIED' ? '✓' : '📄'}
                          </div>
                          <div>
                             <p className="text-sm font-bold text-gray-800">Scan du Diplôme d'État</p>
                             <p className="text-[10px] text-gray-400 uppercase">Synchronisation Ordre National</p>
                          </div>
                       </div>
                       <button type="button" onClick={simulateDiplomaVerify} disabled={diplomaVerified !== 'NONE'} className={`px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${diplomaVerified === 'VERIFIED' ? 'bg-green-100 text-green-600' : 'bg-blue-600 text-white'}`}>
                          {diplomaVerified === 'VERIFIED' ? 'Certifié' : 'Lancer Vérification'}
                       </button>
                    </div>
                 </div>

                 {/* Section: Health status */}
                 <div className="space-y-6">
                    <h3 className="text-xs font-black uppercase text-emerald-800 tracking-widest flex items-center gap-3">
                       <span className="w-6 h-6 bg-emerald-100 rounded flex items-center justify-center text-[10px]">02</span>
                       Bilan de Santé & Prévention
                    </h3>
                    <div className="grid md:grid-cols-2 gap-6">
                       <label className={`flex items-center justify-between p-6 rounded-3xl border-2 transition-all cursor-pointer ${healthStatus.vax ? 'border-emerald-500 bg-emerald-50' : 'border-gray-100 bg-white'}`}>
                          <div className="flex items-center gap-4">
                             <input type="checkbox" className="sr-only" checked={healthStatus.vax} onChange={e => setHealthStatus({...healthStatus, vax: e.target.checked})} />
                             <span className="text-2xl">💉</span>
                             <span className="text-xs font-bold text-gray-700">Carnet Vaccinal à jour</span>
                          </div>
                       </label>
                       <label className={`flex items-center justify-between p-6 rounded-3xl border-2 transition-all cursor-pointer ${healthStatus.medicalVisit ? 'border-emerald-500 bg-emerald-50' : 'border-gray-100 bg-white'}`}>
                          <div className="flex items-center gap-4">
                             <input type="checkbox" className="sr-only" checked={healthStatus.medicalVisit} onChange={e => setHealthStatus({...healthStatus, medicalVisit: e.target.checked})} />
                             <span className="text-2xl">🩺</span>
                             <span className="text-xs font-bold text-gray-700">Visite Médicale effectuée</span>
                          </div>
                       </label>
                    </div>
                 </div>

                 {/* Section: Ethics */}
                 <div className="space-y-6">
                    <h3 className="text-xs font-black uppercase text-emerald-800 tracking-widest flex items-center gap-3">
                       <span className="w-6 h-6 bg-emerald-100 rounded flex items-center justify-center text-[10px]">03</span>
                       Engagement Éthique
                    </h3>
                    <div className="bg-emerald-950 p-8 rounded-[2.5rem] text-white">
                       <p className="text-sm italic text-emerald-100 mb-6">"Je m'engage à soigner tout patient avec dignité et charité."</p>
                       <label className="flex items-center gap-4 cursor-pointer">
                          <input type="checkbox" checked={ethicsSigned} onChange={e => setEthicsSigned(e.target.checked)} className="w-6 h-6 rounded-lg bg-white/10" />
                          <span className="text-xs font-black uppercase tracking-widest">Je signe numériquement cette charte</span>
                       </label>
                    </div>
                 </div>

                 <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase text-gray-400 text-center block tracking-widest">Code RH d'Accréditation</label>
                    <input type="password" required className="w-full px-8 py-7 rounded-[2.5rem] bg-gray-50 text-center font-serif italic text-3xl tracking-[0.4em] border-none" value={serviceCode} onChange={e => setServiceCode(e.target.value)} />
                 </div>

                 <button type="submit" className="w-full bg-[#2563eb] text-white py-8 rounded-3xl font-black uppercase tracking-[0.2em] shadow-2xl">
                    Valider mon Enrôlement
                 </button>
              </form>
           </div>
        </div>
      </div>
    );
  }

  const userTheme = currentUser ? roleThemes[currentUser.role] : null;

  return (
    <div className="flex h-screen bg-gray-50">
      <aside className="w-64 bg-[#064e3b] text-white p-10 flex flex-col gap-8 shadow-2xl">
        <div className="text-2xl italic font-serif border-b border-white/10 pb-6">† Carmel OS</div>
        <button onClick={() => setView(ViewMode.Dashboard)} className={`text-[10px] font-black uppercase text-left tracking-widest flex items-center gap-3 ${view === ViewMode.Dashboard ? 'text-white' : 'opacity-40'}`}>📊 Dashboard</button>
        <button onClick={() => setView(ViewMode.HIVUnit)} className={`text-[10px] font-black uppercase text-left tracking-widest flex items-center gap-3 ${view === ViewMode.HIVUnit ? 'text-white' : 'opacity-40'}`}>🎗️ Unité VIH/ARV</button>
        <button onClick={() => setView(ViewMode.Inbox)} className={`text-[10px] font-black uppercase text-left tracking-widest flex items-center gap-3 ${view === ViewMode.Inbox ? 'text-white' : 'opacity-40'}`}>📬 Inbox</button>
        <button onClick={() => setView(ViewMode.SyncCenter)} className={`text-[10px] font-black uppercase text-left tracking-widest flex items-center gap-3 ${view === ViewMode.SyncCenter ? 'text-white' : 'opacity-40'}`}>🔄 Sync Publique</button>
        <button onClick={() => setView(ViewMode.Login)} className="mt-auto text-[10px] font-black text-red-300 uppercase">🚪 Déconnexion</button>
      </aside>

      <main className="flex-grow p-16 overflow-y-auto">
        <div className="flex justify-between items-center mb-16">
          <div className="flex items-center gap-6">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-lg ${userTheme?.lightBg || 'bg-gray-100'}`}>
              {userTheme?.icon || "👤"}
            </div>
            <div>
              <h1 className="text-4xl font-serif italic text-gray-900 leading-none mb-2">{currentUser?.name}</h1>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">{userTheme?.label} • {currentUser?.id}</p>
            </div>
          </div>
        </div>

        {view === ViewMode.HIVUnit && (
          <div className="space-y-12 animate-fadeIn">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-white p-10 rounded-[4rem] shadow-xl border border-red-50">
               <div>
                  <h2 className="text-3xl font-serif italic text-red-950 mb-2">Smart-Silo VIH</h2>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Saisie intelligente & monitoring de charge virale</p>
               </div>
               <div className="flex gap-4">
                  <button onClick={handleImportExcel} disabled={isImporting} className="bg-emerald-50 text-emerald-700 px-6 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center gap-2">
                    {isImporting ? '⏳ Importation...' : '📂 Import Excel'}
                  </button>
                  <button onClick={startDictation} disabled={isDictating} className={`px-6 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center gap-2 ${isDictating ? 'bg-red-600 text-white animate-pulse' : 'bg-red-50 text-red-600'}`}>
                    {isDictating ? '🎙️ Écoute active...' : '🎤 Saisie Vocale'}
                  </button>
               </div>
            </div>

            <div className="grid lg:grid-cols-3 gap-10">
               <div className="lg:col-span-1 bg-white p-10 rounded-[3rem] shadow-xl border border-gray-100">
                  <h3 className="text-xs font-black uppercase text-gray-400 mb-8 tracking-widest">Nouveau Rapport</h3>
                  <div className="space-y-6">
                     <input type="text" placeholder="ID Patient" className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none font-bold" value={newEntry.patient_id} onChange={e => setNewEntry({...newEntry, patient_id: e.target.value})} />
                     <input type="number" placeholder="Charge Virale" className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none font-bold" value={newEntry.value} onChange={e => setNewEntry({...newEntry, value: parseInt(e.target.value)})} />
                     <button onClick={addViralEntry} className="w-full bg-red-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl">Enregistrer</button>
                  </div>
               </div>
               <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] shadow-xl border border-gray-100">
                  <h3 className="text-xs font-black uppercase text-gray-400 mb-8 tracking-widest">Suivi des Charges Virales</h3>
                  <table className="w-full text-left">
                     <thead>
                        <tr className="border-b border-gray-50">
                           <th className="pb-4 text-[9px] font-black text-gray-300 uppercase">Patient</th>
                           <th className="pb-4 text-[9px] font-black text-gray-300 uppercase">Valeur</th>
                           <th className="pb-4 text-[9px] font-black text-gray-300 uppercase">Status</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-gray-50">
                        {viralHistory.map((h, i) => (
                           <tr key={i} className={`group ${h.status === 'HAUT' ? 'bg-red-50/30' : ''}`}>
                              <td className="py-5 font-bold text-gray-800 text-sm">{h.patient_id}</td>
                              <td className={`py-5 font-black text-sm ${h.status === 'HAUT' ? 'text-red-600' : 'text-emerald-600'}`}>{h.value}</td>
                              <td className="py-5">
                                 <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase ${h.status === 'HAUT' ? 'bg-red-100 text-red-600' : 'bg-emerald-100 text-emerald-600'}`}>{h.status}</span>
                              </td>
                           </tr>
                        ))}
                     </tbody>
                  </table>
               </div>
            </div>
          </div>
        )}

        {view === ViewMode.Dashboard && (
          <div className="space-y-12 animate-fadeIn text-center">
            <div className="grid grid-cols-3 gap-8 text-left">
              <StatCard label="Patients VIH" value="452" icon="🎗️" color="text-red-600" />
              <StatCard label="Alertes" value="14" icon="⚠️" color="text-orange-600" />
              <StatCard label="Stock ARV" value="24j" icon="💊" color="text-emerald-600" />
            </div>
            <div className="bg-white p-20 rounded-[4rem] border border-emerald-50">
               <h2 className="text-4xl font-serif italic text-emerald-950 mb-4">Bienvenue, {currentUser?.name}</h2>
               <p className="text-gray-400 font-medium italic">Sélectionnez une unité de soin pour commencer.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: any) => (
  <div className="bg-white p-10 rounded-[3.5rem] shadow-xl border border-gray-50 flex flex-col items-center text-center">
    <div className={`w-14 h-14 rounded-2xl bg-gray-50 flex items-center justify-center text-2xl mb-6 shadow-inner`}>{icon}</div>
    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">{label}</p>
    <p className={`text-5xl font-black ${color}`}>{value}</p>
  </div>
);

export default StaffPortal;
