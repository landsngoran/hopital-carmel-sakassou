
import React, { useState } from 'react';
import { Page } from '../types';

interface DiseaseInfoProps {
  onNavigate?: (page: Page) => void;
}

const DiseaseInfo: React.FC<DiseaseInfoProps> = ({ onNavigate }) => {
  const [lang, setLang] = useState<'FR' | 'BAO'>('FR');

  const content = {
    FR: {
      title: "Comprendre l'Ulcère de Buruli",
      subtitle: "Savoir pour prévenir, agir pour guérir.",
      whatIsIt: "L'ulcère de Buruli est une maladie infectieuse causée par la bactérie *Mycobacterium ulcerans*. Elle attaque la peau et les tissus mous, provoquant de larges plaies si elle n'est pas traitée tôt.",
      symptoms: [
        "Un petit nodule ou une plaque enflée sans douleur.",
        "Une perte de sensibilité au niveau de la zone touchée.",
        "Une plaie qui s'élargit progressivement avec des bords 'décollés'.",
        "Une raideur des articulations si la plaie est proche d'un membre."
      ],
      prevention: "Évitez tout contact prolongé avec les eaux stagnantes et portez des vêtements couvrants lors des travaux agricoles. Signalez tout bouton suspect immédiatement."
    },
    BAO: {
      title: "Ulcère de Buruli i si n'gata",
      subtitle: "I si n'gata, i si n'zran.",
      whatIsIt: "Ulcère de Buruli ni kpokpo n'gouan o. Ba ni sra kô o, i sran mou i woun i.",
      symptoms: [
        "N'zran kan ni wun i woun mou bé nan.",
        "I wun i bé nan kpokpo...",
        "Plaie ni bé lo kpa...",
        "I ja mou i sa mou bé kpin."
      ],
      prevention: "Moun bé nan n'zouè klwa o. Kpô n'zran i kpa. Sé n'zran o, wa klé docteur."
    }
  };

  const current = content[lang];

  return (
    <div className="animate-fadeIn pb-20">
      <div className="bg-blue-900 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <h1 className="text-4xl font-bold mb-2">{current.title}</h1>
            <p className="text-blue-200">{current.subtitle}</p>
          </div>
          <div className="flex bg-white/10 p-1 rounded-full">
            <button 
              onClick={() => setLang('FR')}
              className={`px-4 py-1 rounded-full text-xs font-bold transition-all ${lang === 'FR' ? 'bg-white text-blue-900' : 'text-white'}`}
            >
              FRANÇAIS
            </button>
            <button 
              onClick={() => setLang('BAO')}
              className={`px-4 py-1 rounded-full text-xs font-bold transition-all ${lang === 'BAO' ? 'bg-white text-blue-900' : 'text-white'}`}
            >
              BAOULÉ (Local)
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 mt-12 space-y-12">
        <section className="bg-white p-8 rounded-3xl shadow-sm border border-blue-50">
          <h2 className="text-2xl font-bold text-blue-900 mb-4">C'est quoi ?</h2>
          <p className="text-gray-700 leading-relaxed text-lg italic">
            {current.whatIsIt}
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-blue-900 mb-6">Les Symptômes</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {current.symptoms.map((s, i) => (
              <div key={i} className="flex items-start gap-4 bg-emerald-50 p-6 rounded-2xl">
                <span className="bg-emerald-600 text-white w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold">
                  {i + 1}
                </span>
                <p className="text-emerald-900 font-medium">{s}</p>
              </div>
            ))}
          </div>
        </section>

        <div className="bg-orange-50 border-l-4 border-orange-400 p-8 rounded-r-3xl">
          <h3 className="text-xl font-bold text-orange-800 mb-2">💡 Conseil de prévention</h3>
          <p className="text-orange-900">{current.prevention}</p>
        </div>

        <section className="text-center py-8">
          <p className="text-gray-500 mb-6 italic">Vous avez un doute ? N'attendez pas que la plaie s'agrandisse.</p>
          <button 
            onClick={() => {
              if (onNavigate) {
                onNavigate(Page.PatientPortal);
              }
            }}
            className="bg-blue-600 text-white px-12 py-5 rounded-full font-bold hover:bg-blue-700 transition-all shadow-xl hover:scale-105 active:scale-95 text-lg"
          >
            Consultez gratuitement
          </button>
        </section>
      </div>
    </div>
  );
};

export default DiseaseInfo;
