
import React, { useState } from 'react';
import { TEAM } from '../constants';

interface GalleryImage {
  url: string;
  caption: string;
  category: string;
}

const GALLERY: GalleryImage[] = [
  {
    url: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=1200",
    caption: "Le nouveau pavillon de chirurgie de Sakassou.",
    category: "Hôpital"
  },
  {
    url: "https://images.unsplash.com/photo-1579154235602-3c2c2992d234?auto=format&fit=crop&q=80&w=1200",
    caption: "Équipement de pointe pour le diagnostic bactérien.",
    category: "Laboratoire"
  },
  {
    url: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=1200",
    caption: "Mme Amoin lors d'une mission de sensibilisation en village.",
    category: "Communauté"
  },
  {
    url: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=1200",
    caption: "La rééducation, étape clé de la guérison.",
    category: "Soins"
  },
  {
    url: "https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?auto=format&fit=crop&q=80&w=1200",
    caption: "Consultation gratuite pour un enfant du village d'Assandré.",
    category: "Patients"
  },
  {
    url: "https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=1200",
    caption: "L'équipe soignante réunie pour le briefing matinal.",
    category: "Équipe"
  }
];

const About: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const testimonials = [
    {
      text: "Grâce aux soins gratuits pour l'ulcère de Buruli, j'ai pu reprendre mon travail aux champs. Dr. Konan et les sœurs m'ont traité comme leur propre fils.",
      author: "Kouamé N.",
      origin: "Agriculteur, Sakassou",
      icon: "🌱"
    },
    {
      text: "Ma fille ne pouvait plus marcher à cause d'une plaie sévère. Aujourd'hui, elle court vers l'école. Notre-Dame du Carmel est un don du ciel pour nous.",
      author: "Ahou T.",
      origin: "Mère de famille, Assandré",
      icon: "🎒"
    },
    {
      text: "L'opération de la cataracte a changé ma vie. Je peux enfin revoir le visage de mes petits-enfants. La propreté et la gentillesse ici sont exemplaires.",
      author: "N'Goran K.",
      origin: "Doyen, Quartier Commerce",
      icon: "👁️"
    }
  ];

  return (
    <div className="animate-fadeIn">
      <div className="bg-emerald-900 text-white py-20 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 relative z-10 text-center md:text-left">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 italic leading-tight">Notre Engagement & Racines</h1>
          <p className="text-xl text-emerald-100 max-w-3xl leading-relaxed">
            Héritiers d'une tradition de soin et de charité, nous bâtissons l'avenir de la santé à Sakassou avec une expertise 100% ivoirienne.
          </p>
        </div>
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
      </div>

      {/* Pourquoi Sakassou Section */}
      <div className="max-w-7xl mx-auto px-4 py-24 grid lg:grid-cols-2 gap-20 items-center">
        <div className="order-2 lg:order-1">
          <h2 className="text-4xl font-bold text-emerald-900 mb-8 font-serif leading-tight italic">Pourquoi Sakassou ?</h2>
          <div className="space-y-6 text-gray-700 leading-relaxed text-lg italic">
            <p>
              Situé au cœur du pays Baoulé, notre hôpital répond à un besoin vital : apporter la médecine de pointe là où elle manque le plus. Nous luttons quotidiennement contre l'exclusion liée à l'ulcère de Buruli.
            </p>
            <p>
              Chaque patient franchissant nos portes est traité avec la dignité d'un enfant de Dieu, dans le respect de nos valeurs chrétiennes de compassion et de service désintéressé.
            </p>
          </div>
          <div className="mt-12 flex flex-wrap gap-4">
            <div className="bg-emerald-50 px-8 py-4 rounded-2xl border-b-4 border-emerald-600 shadow-sm">
               <span className="block font-black text-emerald-900 text-2xl">50</span>
               <span className="text-[10px] uppercase font-bold text-emerald-600">Lits d'accueil</span>
            </div>
            <div className="bg-orange-50 px-8 py-4 rounded-2xl border-b-4 border-orange-600 shadow-sm">
               <span className="block font-black text-orange-900 text-2xl">24/7</span>
               <span className="text-[10px] uppercase font-bold text-orange-600">Service Urgences</span>
            </div>
          </div>
        </div>
        <div className="order-1 lg:order-2 relative group">
          <div className="absolute -inset-4 bg-emerald-100/50 rounded-[3rem] blur-2xl group-hover:bg-orange-100/50 transition-colors duration-700"></div>
          <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl border-[12px] border-white transform transition-transform group-hover:scale-[1.02]">
            <img 
              src="https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&q=80&w=800" 
              alt="Enfants en bonne santé à Sakassou" 
              className="w-full h-[550px] object-cover" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-emerald-900/60 to-transparent"></div>
            <div className="absolute bottom-10 left-10 text-white">
               <p className="text-sm font-black uppercase tracking-[0.2em] mb-2">Impact Direct</p>
               <h3 className="text-2xl font-serif italic">Restaurer la marche, <br/>rendre l'espoir.</h3>
            </div>
          </div>
        </div>
      </div>

      {/* GALERIE D'IMAGES - NEW SECTION */}
      <section className="py-24 bg-white px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl font-bold text-emerald-900 mb-4 font-serif italic">Vivre le Carmel</h2>
            <p className="text-emerald-600 font-black text-[10px] uppercase tracking-[0.3em]">Instants de vie et de guérison à Sakassou</p>
            <div className="w-20 h-1 bg-orange-500 mt-4"></div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {GALLERY.map((img, idx) => (
              <div 
                key={idx} 
                onClick={() => setSelectedImage(img)}
                className="group relative cursor-pointer overflow-hidden rounded-[2.5rem] aspect-[4/3] bg-emerald-50 shadow-lg shadow-emerald-900/5 border border-emerald-50 active:scale-95 transition-all"
              >
                <img 
                  src={img.url} 
                  alt={img.caption} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                  <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-2">{img.category}</span>
                  <p className="text-white text-sm italic font-medium">{img.caption}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox for Gallery */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-emerald-950/90 backdrop-blur-xl animate-fadeIn"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-5xl w-full" onClick={e => e.stopPropagation()}>
            <button 
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 text-white text-4xl hover:scale-110 transition-transform"
            >
              ✕
            </button>
            <img 
              src={selectedImage.url} 
              alt={selectedImage.caption} 
              className="w-full h-auto max-h-[85vh] object-contain rounded-3xl shadow-2xl border border-white/10" 
            />
            <div className="mt-6 text-center">
              <span className="bg-emerald-600 px-4 py-1.5 rounded-full text-[10px] font-black text-white uppercase tracking-widest mb-2 inline-block">
                {selectedImage.category}
              </span>
              <p className="text-emerald-100 text-xl font-serif italic">{selectedImage.caption}</p>
            </div>
          </div>
        </div>
      )}

      {/* Team Section */}
      <section className="bg-gray-50 py-32 px-4 relative overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-24">
            <h2 className="text-5xl font-bold text-emerald-900 mb-6 font-serif italic">Experts du Carmel</h2>
            <p className="text-emerald-600 italic uppercase tracking-[0.4em] text-[10px] font-black">L'Excellence et la Bienveillance de Sakassou</p>
            <div className="w-24 h-1.5 bg-orange-500 mx-auto mt-8 rounded-full"></div>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-14">
            {TEAM.map((member, i) => (
              <div key={i} className="group perspective h-[550px]">
                <div className="relative w-full h-full transition-all duration-700 transform-style-3d group-hover:rotate-y-180">
                  <div className="absolute inset-0 backface-hidden bg-white p-4 rounded-[4rem] shadow-2xl shadow-emerald-900/5 border border-emerald-50 flex flex-col group-hover:shadow-emerald-900/20">
                    <div className="relative h-[350px] rounded-[3.5rem] overflow-hidden mb-8">
                      <img 
                        src={member.image} 
                        alt={member.name} 
                        className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-700 scale-105 group-hover:scale-110" 
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/40 to-transparent"></div>
                    </div>
                    <div className="px-6 text-center">
                      <span className="inline-block bg-emerald-50 text-emerald-700 px-5 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.15em] mb-4 border border-emerald-100">
                        {member.role}
                      </span>
                      <h3 className="text-2xl font-bold text-emerald-900 font-serif leading-none mb-4">{member.name}</h3>
                    </div>
                  </div>
                  <div className="absolute inset-0 backface-hidden rotate-y-180 bg-emerald-900 p-12 rounded-[4rem] shadow-2xl text-white flex flex-col justify-center items-center text-center border-[8px] border-emerald-800">
                    <div className="w-20 h-20 bg-white/10 rounded-3xl flex items-center justify-center text-4xl mb-10 shadow-inner group-hover:rotate-12 transition-transform">✨</div>
                    <h3 className="text-2xl font-bold mb-4 font-serif italic text-emerald-300">{member.name}</h3>
                    <p className="text-base text-emerald-50 leading-relaxed mb-10 italic">"{member.bio}"</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Témoignages Section */}
      <section className="py-32 bg-emerald-950 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-gray-50 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 font-serif italic">Paroles de Guéris</h2>
            <p className="text-emerald-400 italic uppercase tracking-[0.4em] text-[10px] font-black">L'Impact du Carmel au Quotidien</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t, idx) => (
              <div key={idx} className="bg-white/5 backdrop-blur-md border border-white/10 p-10 rounded-[3rem] hover:bg-white/10 transition-all group">
                <div className="text-4xl mb-8 group-hover:scale-125 transition-transform duration-500">{t.icon}</div>
                <div className="text-emerald-500 text-4xl font-serif mb-4 leading-none">“</div>
                <p className="text-emerald-50 text-lg leading-relaxed mb-8 italic">{t.text}</p>
                <div className="pt-6 border-t border-white/10">
                  <h4 className="text-white font-bold text-base">{t.author}</h4>
                  <p className="text-emerald-500 text-[10px] font-black uppercase tracking-widest">{t.origin}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <style>{`
        .perspective { perspective: 2000px; }
        .transform-style-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
};

export default About;
