
import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';

const PatientPortal: React.FC = () => {
  const [view, setView] = useState<'LOGIN' | 'REGISTER' | 'SCANNING' | 'DASHBOARD'>('LOGIN');
  const [patientId, setPatientId] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [painLevel, setPainLevel] = useState<number>(2);
  const [activeHistory, setActiveHistory] = useState<any[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);

  const [regData, setRegData] = useState({
    name: '',
    loc: '',
    phone: '',
    consent: false,
    symptoms: ''
  });

  useEffect(() => {
    if (view === 'DASHBOARD' && patientId) {
      supabase.from('patient_history').select().then(({ data }: any) => {
        setActiveHistory(data || []);
      });
    }
  }, [view, patientId]);

  const startScanning = async () => {
    setView('SCANNING');
    setIsScanning(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (e) { console.error("Caméra non dispo"); }

    setTimeout(async () => {
      const newId = `ND-${Math.floor(Math.random() * 9000) + 1000}`;
      await supabase.from('patient_records').insert({ ...regData, id: newId });
      
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(t => t.stop());
      
      setPatientId(newId);
      setIsScanning(false);
      setView('DASHBOARD');
    }, 4000);
  };

  const handleLogin = () => {
    supabase.from('patient_records').eq('id', patientId.toUpperCase()).then(({ data }: any) => {
      if (data.length > 0) setView('DASHBOARD');
      else alert("ID Patient inconnu.");
    });
  };

  if (view === 'SCANNING') {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
        <div className="relative w-80 h-80 mb-12 bg-black rounded-[4rem] overflow-hidden border-4 border-emerald-500 shadow-2xl">
          <video ref={videoRef} autoPlay className="w-full h-full object-cover grayscale opacity-60" />
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <div className="w-[65%] h-[75%] border-2 border-emerald-400/50 rounded-[50%] shadow-[0_0_0_500px_rgba(0,0,0,0.4)]"></div>
          </div>
          <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500 shadow-[0_0_15px_#10b981] animate-scanline z-10"></div>
        </div>
        <h2 className="text-3xl font-serif italic text-emerald-950 mb-4">Initialisation de l'Accréditation Patient</h2>
        <p className="text-gray-400 font-medium max-w-sm">Signature biométrique en cours... Sécurisation du dossier sur le Cloud Sakassou.</p>
        <style>{`
          @keyframes scanline {
            0% { top: 15%; opacity: 0; }
            50% { opacity: 1; }
            100% { top: 85%; opacity: 0; }
          }
          .animate-scanline { animation: scanline 2.5s ease-in-out infinite; }
        `}</style>
      </div>
    );
  }

  if (view === 'LOGIN') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 animate-fadeIn">
        <div className="bg-white p-12 rounded-[4rem] shadow-2xl w-full max-w-md text-center border border-gray-100">
          <div className="w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center mx-auto mb-8 text-4xl shadow-inner">🔓</div>
          <h1 className="text-3xl font-bold text-emerald-900 font-serif italic mb-2">Accès Patient</h1>
          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-10">Authentification Accréditée Sécurisée</p>
          <input 
            type="text" placeholder="VOTRE ID (EX: ND-1234)" 
            className="w-full px-8 py-6 rounded-3xl bg-gray-50 mb-6 border-none outline-none focus:ring-2 focus:ring-emerald-500 font-black text-center text-xl tracking-tighter uppercase"
            value={patientId} onChange={e => setPatientId(e.target.value)}
          />
          <button onClick={handleLogin} className="w-full bg-emerald-950 text-white py-6 rounded-[2rem] font-black uppercase tracking-widest shadow-xl hover:bg-emerald-800 transition-all active:scale-95">Ouvrir le Dossier</button>
          <div className="mt-10 pt-8 border-t border-gray-50">
            <button onClick={() => setView('REGISTER')} className="text-[10px] font-black text-emerald-600 uppercase tracking-widest hover:text-orange-500 transition-colors">
               + Créer une nouvelle accréditation
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'REGISTER') {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-12 animate-fadeIn">
        <div className="bg-white p-10 md:p-16 rounded-[5rem] shadow-2xl w-full max-w-3xl border border-emerald-50">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-serif italic mb-4 text-emerald-950">Ouverture de Dossier</h2>
            <div className="w-12 h-1 bg-orange-500 mx-auto rounded-full"></div>
          </div>
          
          <form onSubmit={(e) => { e.preventDefault(); if(regData.consent) startScanning(); else alert("Consentement requis"); }} className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
               <div className="space-y-2">
                 <label className="text-[10px] font-black uppercase text-gray-300 ml-4 tracking-widest">Identité Patient</label>
                 <input type="text" placeholder="Prénom Nom" required className="w-full px-8 py-5 rounded-[2rem] bg-gray-50 outline-none font-bold text-emerald-900 border-2 border-transparent focus:border-emerald-200 transition-all" value={regData.name} onChange={e => setRegData({...regData, name: e.target.value})} />
               </div>
               <div className="space-y-2">
                 <label className="text-[10px] font-black uppercase text-gray-300 ml-4 tracking-widest">Zone de Résidence</label>
                 <input type="text" placeholder="Village / Quartier" required className="w-full px-8 py-5 rounded-[2rem] bg-gray-50 outline-none font-bold text-emerald-900 border-2 border-transparent focus:border-emerald-200 transition-all" value={regData.loc} onChange={e => setRegData({...regData, loc: e.target.value})} />
               </div>
               <div className="space-y-2 md:col-span-2">
                 <label className="text-[10px] font-black uppercase text-gray-300 ml-4 tracking-widest">Symptômes actuels</label>
                 <textarea rows={3} placeholder="Décrivez l'état de votre peau..." className="w-full px-8 py-5 rounded-[2.5rem] bg-gray-50 outline-none font-medium italic text-emerald-900 border-2 border-transparent focus:border-emerald-200 transition-all resize-none" value={regData.symptoms} onChange={e => setRegData({...regData, symptoms: e.target.value})}></textarea>
               </div>
            </div>
            
            <div className="p-8 bg-emerald-50 rounded-[3rem] border border-emerald-100">
               <label className="flex items-start gap-6 cursor-pointer group">
                  <div className="relative mt-1">
                    <input type="checkbox" checked={regData.consent} onChange={e => setRegData({...regData, consent: e.target.checked})} className="peer sr-only" />
                    <div className="w-8 h-8 bg-white border-2 border-emerald-200 rounded-xl peer-checked:bg-emerald-600 peer-checked:border-emerald-600 transition-all"></div>
                    <span className="absolute inset-0 flex items-center justify-center text-white opacity-0 peer-checked:opacity-100 transition-opacity">✓</span>
                  </div>
                  <div className="flex-grow">
                    <p className="text-xs text-emerald-900 font-bold uppercase tracking-widest mb-2 group-hover:text-emerald-700">Consentement Éclairé</p>
                    <p className="text-[11px] text-emerald-700/70 leading-relaxed italic font-medium">
                      J'accepte que mes données cliniques soient traitées par l'Hôpital pour assurer la continuité de mes soins.
                    </p>
                  </div>
               </label>
            </div>

            <button type="submit" className="w-full bg-emerald-950 text-white py-6 rounded-[2.5rem] font-black uppercase tracking-[0.2em] shadow-2xl hover:bg-emerald-800 transition-all active:scale-95">Initialiser l'Analyse Accréditée</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-16 animate-fadeIn pb-40">
       <div className="bg-emerald-950 text-white p-12 md:p-20 rounded-[5rem] mb-12 shadow-2xl relative overflow-hidden group">
          <div className="absolute -right-20 -bottom-20 text-[25rem] opacity-5 italic font-serif group-hover:rotate-6 transition-transform">†</div>
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-10">
            <div>
              <div className="flex items-center gap-4 mb-6">
                 <span className="bg-orange-500 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">Accréditation Active</span>
                 <span className="text-emerald-400 font-mono font-bold tracking-widest">{patientId}</span>
              </div>
              <h2 className="text-5xl font-serif italic mb-4 leading-tight">Chemin vers la Guérison</h2>
              <p className="text-emerald-100/60 max-w-md italic text-lg leading-relaxed italic">
                La technologie au service de votre dignité.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-2xl p-10 rounded-[4rem] border border-white/10 flex flex-col items-center">
               <p className="text-[10px] font-black uppercase opacity-60 mb-4 tracking-widest">Prochain Rendez-vous</p>
               <p className="text-3xl font-black mb-1">MARDI 24</p>
               <p className="text-emerald-400 font-bold italic">Soin de plaie à 08h30</p>
            </div>
          </div>
       </div>

       <div className="grid lg:grid-cols-3 gap-10">
          <div className="lg:col-span-1 bg-white p-12 rounded-[4rem] shadow-xl border border-emerald-50">
             <h3 className="text-2xl font-serif italic text-emerald-950 mb-8">Ressenti Douleur</h3>
             <div className="space-y-10">
                <div className="flex justify-between items-center px-4">
                   {[1, 2, 3, 4, 5].map(v => (
                     <button 
                       key={v} 
                       onClick={() => setPainLevel(v)}
                       className={`w-12 h-12 rounded-2xl text-2xl flex items-center justify-center transition-all ${painLevel === v ? 'bg-emerald-500 text-white scale-125 rotate-6 shadow-xl' : 'bg-gray-50'}`}
                     >
                       {v === 1 ? '😊' : v === 2 ? '😐' : v === 3 ? '😟' : v === 4 ? '😫' : '😖'}
                     </button>
                   ))}
                </div>
                <div className={`p-6 rounded-3xl bg-gray-50 border-2 border-emerald-100 text-center`}>
                   <p className="text-[10px] font-black uppercase mb-1 tracking-widest text-emerald-950 opacity-60">Tri Clinique</p>
                   <p className="font-bold uppercase tracking-tighter text-emerald-900">
                      {painLevel >= 4 ? "ALERTE URGENCE" : "SURVEILLANCE"}
                   </p>
                </div>
             </div>
          </div>

          <div className="lg:col-span-2 bg-white p-12 rounded-[4rem] shadow-xl border border-emerald-50">
             <h3 className="text-2xl font-serif italic text-emerald-950 mb-10">Journal de Soins</h3>
             <div className="space-y-6">
                {activeHistory.map((item, i) => (
                  <div key={i} className="flex gap-8 p-8 rounded-[2.5rem] bg-gray-50 border border-emerald-50">
                    <div className="flex-shrink-0 w-16 h-16 bg-white rounded-3xl flex flex-col items-center justify-center text-emerald-900 shadow-sm">
                       <span className="text-xl font-black">{new Date(item.date).getDate()}</span>
                       <span className="text-[8px] font-black uppercase opacity-40">MARS</span>
                    </div>
                    <div>
                       <div className="flex items-center gap-3 mb-2">
                          <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">{item.provider}</span>
                       </div>
                       <h4 className="text-xl font-bold text-emerald-950 mb-2">{item.title}</h4>
                       <p className="text-sm text-gray-500 italic leading-relaxed">{item.note}</p>
                    </div>
                  </div>
                ))}
             </div>
          </div>
       </div>
    </div>
  );
};

export default PatientPortal;
