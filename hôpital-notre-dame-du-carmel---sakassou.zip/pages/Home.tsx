
import React from 'react';
import { Page } from '../types';
import { NEWS } from '../constants';
import { translations } from '../translations';

interface HomeProps {
  onNavigate: (page: Page) => void;
  lang: 'fr' | 'en';
}

const Home: React.FC<HomeProps> = ({ onNavigate, lang }) => {
  const t = translations[lang];

  return (
    <div className="animate-fadeIn">
      <section className="relative h-[650px] flex items-center text-white overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=1600" 
          className="absolute inset-0 w-full h-full object-cover brightness-[0.35] contrast-125"
          alt="Accueil Hôpital Sakassou"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-950/80 to-transparent"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 w-full">
          <div className="max-w-2xl">
            <div className="flex items-center gap-3 mb-6">
              <span className="bg-emerald-600 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest shadow-lg">Sakassou, Gbêkê</span>
              <span className="w-8 h-[2px] bg-emerald-500/50"></span>
              <span className="text-emerald-400 text-xs font-bold uppercase tracking-widest">{lang === 'fr' ? "Côte d'Ivoire" : "Ivory Coast"}</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight font-serif">
              {t.hero.title} <span className="text-emerald-400 italic text-shadow">{t.hero.titleAccent}</span>.
            </h1>
            <p className="text-xl mb-8 text-gray-200 leading-relaxed">
              {t.hero.subtitle}
            </p>
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onNavigate(Page.Booking)}
                className="bg-white text-emerald-900 px-10 py-5 rounded-full font-bold text-lg hover:bg-emerald-50 transition-all shadow-xl shadow-black/20"
              >
                {t.hero.cta_rdv}
              </button>
              <button 
                onClick={() => onNavigate(Page.DiseaseInfo)}
                className="bg-emerald-600/30 backdrop-blur-md border border-white/20 text-white px-10 py-5 rounded-full font-bold text-lg hover:bg-emerald-600/50 transition-all"
              >
                {t.hero.cta_info}
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white py-16 shadow-inner">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="border-r border-gray-100 last:border-none">
            <div className="text-4xl font-bold text-emerald-700 mb-2 font-serif">500+</div>
            <div className="text-gray-400 text-[10px] uppercase font-black tracking-widest">{t.stats.cures}</div>
          </div>
          <div className="border-r border-gray-100 last:border-none">
            <div className="text-4xl font-bold text-emerald-700 mb-2 font-serif">50</div>
            <div className="text-gray-400 text-[10px] uppercase font-black tracking-widest">{t.stats.beds}</div>
          </div>
          <div className="border-r border-gray-100 last:border-none">
            <div className="text-4xl font-bold text-emerald-700 mb-2 font-serif">24/7</div>
            <div className="text-gray-400 text-[10px] uppercase font-black tracking-widest">{t.stats.emergency}</div>
          </div>
          <div className="border-r border-gray-100 last:border-none">
            <div className="text-4xl font-bold text-emerald-700 mb-2 font-serif">100%</div>
            <div className="text-gray-400 text-[10px] uppercase font-black tracking-widest">{t.stats.dedication}</div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-gray-50/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-emerald-900 mb-4 font-serif">{lang === 'fr' ? 'Actions à Sakassou' : 'Activities in Sakassou'}</h2>
            <div className="w-20 h-1 bg-emerald-600 rounded"></div>
          </div>
          <div className="grid md:grid-cols-2 gap-10">
            {NEWS.map(item => (
              <div key={item.id} className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-emerald-50 flex flex-col sm:flex-row gap-6 hover:shadow-xl transition-all group">
                <div className="flex-shrink-0 w-20 h-20 bg-emerald-900 rounded-2xl flex flex-col items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                  <span className="text-2xl font-bold leading-none">{item.date.split(' ')[0]}</span>
                  <span className="text-[10px] uppercase font-black text-emerald-400">{item.date.split(' ')[1]}</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-emerald-900 mb-3 font-serif">{item.title}</h3>
                  <p className="text-gray-500 mb-6 text-sm leading-relaxed italic">{item.summary}</p>
                  <button className="text-emerald-600 font-black text-xs hover:tracking-widest transition-all uppercase flex items-center gap-2">
                    {lang === 'fr' ? 'Lire le témoignage' : 'Read testimony'} <span>→</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
