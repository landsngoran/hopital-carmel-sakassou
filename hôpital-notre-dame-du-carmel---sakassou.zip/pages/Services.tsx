
import React, { useState } from 'react';
import { SERVICES } from '../constants';
import { Service } from '../types';

const Services: React.FC = () => {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [filter, setFilter] = useState<'Tous' | 'Gratuit' | 'Payant'>('Tous');

  const specializedUnits = [
    { title: "Consultations 24/7", desc: "Accueil permanent pour les urgences médicales et le triage.", icon: "🩺" },
    { title: "Unité Vision & Cœur", desc: "Plateau technique pour les examens ECG et ophtalmiques de précision.", icon: "❤️" },
    { title: "Bloc de Chirurgie", desc: "Dédié aux greffes cutanées et interventions réparatrices.", icon: "🏥" },
    { title: "Salles d'Hospitalisation", desc: "50 lits équipés pour les soins de longue durée et le repos.", icon: "🛌" }
  ];

  const filteredServices = SERVICES.filter(s => {
    if (filter === 'Tous') return true;
    if (filter === 'Gratuit') return s.price === 'Gratuit' || s.price === 'Pris en charge';
    return s.price !== 'Gratuit' && s.price !== 'Pris en charge';
  });

  const handleCall = () => {
    window.location.href = "tel:+22521010203";
  };

  // Helper to determine availability text
  const getAvailability = (id: string) => {
    if (id === 'ophtalmo' || id === 'cardio') return "Sur RDV uniquement";
    if (id === 'buruli-diag' || id === 'general-consult') return "Sans RDV / Urgence";
    return "Lundi - Samedi";
  };

  return (
    <div className="animate-fadeIn pb-24 bg-gray-50/30">
      {/* Header */}
      <div className="bg-emerald-900 text-white py-24 px-4 relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 italic">Nos Tarifs & Spécialités</h1>
          <p className="text-xl text-emerald-100 max-w-3xl mx-auto leading-relaxed">
            Hôpital Notre-Dame du Carmel : Une offre de soins complète, transparente et accessible pour la région de Sakassou.
          </p>
        </div>
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
      </div>

      {/* Navigation de filtrage innovante */}
      <div className="max-w-7xl mx-auto px-4 -mt-8 relative z-20">
        <div className="flex justify-center">
          <div className="bg-white p-2 rounded-2xl shadow-xl border border-emerald-50 flex gap-2">
            {['Tous', 'Gratuit', 'Payant'].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f as any)}
                className={`px-8 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${
                  filter === f ? 'bg-emerald-600 text-white shadow-lg' : 'text-emerald-900 hover:bg-emerald-50'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 mt-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filteredServices.map(service => (
            <div key={service.id} className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-emerald-900/5 border border-emerald-50 hover:border-emerald-200 transition-all group relative overflow-hidden flex flex-col hover:-translate-y-2">
              {/* Badge Prix */}
              <div className={`absolute top-0 right-0 px-6 py-2 rounded-bl-2xl font-black text-[10px] uppercase tracking-tighter shadow-md ${
                service.price === 'Gratuit' || service.price === 'Pris en charge' 
                ? 'bg-orange-500 text-white' 
                : 'bg-emerald-600 text-white'
              }`}>
                {service.price}
              </div>

              <div className="w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center text-4xl mb-8 group-hover:rotate-6 transition-transform group-hover:bg-emerald-100">
                {service.icon}
              </div>

              <h3 className="text-2xl font-bold text-emerald-900 mb-4 font-serif">{service.title}</h3>
              <p className="text-gray-500 mb-4 leading-relaxed text-sm italic">
                {service.description}
              </p>
              
              {(service.id === 'ophtalmo' || service.id === 'cardio') && (
                <div className="mb-6 flex items-center gap-2 text-[10px] font-bold text-orange-600 uppercase bg-orange-50 px-3 py-1 rounded-full w-fit">
                  <span className="animate-pulse">●</span> Uniquement sur RDV
                </div>
              )}

              <div className="mt-auto pt-8 border-t border-emerald-50 grid grid-cols-2 gap-4">
                <button 
                  onClick={handleCall}
                  className="flex items-center justify-center gap-2 bg-emerald-50 text-emerald-700 py-4 rounded-2xl font-bold text-xs hover:bg-emerald-100 transition-all"
                >
                  <span>📞</span> Appeler
                </button>
                <button 
                  onClick={() => setSelectedService(service)}
                  className="bg-emerald-900 text-white py-4 rounded-2xl font-bold text-xs hover:bg-emerald-800 transition-all shadow-lg shadow-emerald-900/10"
                >
                  Détails
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal de Détails */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/40 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-[3rem] w-full max-w-2xl overflow-hidden shadow-2xl relative">
            <button 
              onClick={() => setSelectedService(null)}
              className="absolute top-6 right-6 w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-500 hover:bg-red-50 hover:text-red-500 transition-all z-10"
            >
              ✕
            </button>
            <div className="bg-emerald-900 p-12 text-white relative">
              <div className="text-6xl mb-4">{selectedService.icon}</div>
              <h2 className="text-3xl font-bold font-serif mb-2">{selectedService.title}</h2>
              <div className="flex gap-2 items-center">
                <div className="bg-emerald-400/20 inline-block px-4 py-1 rounded-full text-[10px] font-bold uppercase">
                  Tarif : {selectedService.price}
                </div>
                {(selectedService.id === 'ophtalmo' || selectedService.id === 'cardio') && (
                  <div className="bg-orange-500 text-white px-4 py-1 rounded-full text-[10px] font-bold uppercase shadow-lg shadow-orange-900/20">
                    RDV Obligatoire
                  </div>
                )}
              </div>
            </div>
            <div className="p-12 space-y-6">
              <div>
                <h4 className="text-xs font-black text-emerald-900 uppercase tracking-widest mb-3">Description Complète</h4>
                <p className="text-gray-600 leading-relaxed italic">
                  Ce service est conçu pour répondre aux besoins spécifiques des habitants de Sakassou. {selectedService.description} Nous utilisons un matériel de pointe et garantissons un suivi post-consultation rigoureux.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-6 pt-4">
                <div className="bg-gray-50 p-4 rounded-2xl">
                  <span className="text-emerald-600 font-bold block mb-1 text-xs">Temps d'attente</span>
                  <p className="text-emerald-950 font-black text-sm">~ 15-30 min</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-2xl">
                  <span className="text-emerald-600 font-bold block mb-1 text-xs">Disponibilité</span>
                  <p className={`font-black text-sm ${selectedService.id === 'ophtalmo' || selectedService.id === 'cardio' ? 'text-orange-600' : 'text-emerald-950'}`}>
                    {getAvailability(selectedService.id)}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => { setSelectedService(null); handleCall(); }}
                className="w-full bg-emerald-900 text-white py-5 rounded-2xl font-bold hover:bg-emerald-800 transition-all shadow-xl"
              >
                {selectedService.id === 'ophtalmo' || selectedService.id === 'cardio' ? 'Prendre rendez-vous' : 'Confirmer par téléphone'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Infrastructure innovate - Micro-cards */}
      <div className="max-w-7xl mx-auto px-4 mt-32">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-emerald-900 mb-4 font-serif italic">Notre Plateau Technique</h2>
          <div className="w-16 h-1 bg-orange-500 mx-auto rounded"></div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {specializedUnits.map((unit, i) => (
            <div key={i} className="bg-white border border-emerald-50 p-8 rounded-[2rem] hover:shadow-2xl hover:shadow-emerald-900/5 transition-all text-center">
              <div className="text-4xl mb-6">{unit.icon}</div>
              <h4 className="font-bold text-emerald-900 mb-3">{unit.title}</h4>
              <p className="text-xs text-gray-500 leading-relaxed">{unit.desc}</p>
            </div>
          ))}
        </div>
      </div>
      
      {/* CTA innovant */}
      <div className="max-w-5xl mx-auto px-4 mt-32">
        <div className="bg-white rounded-[4rem] p-1 shadow-2xl shadow-emerald-900/10 overflow-hidden border border-emerald-50">
          <div className="bg-emerald-950 rounded-[3.8rem] p-12 md:p-20 text-white flex flex-col md:flex-row items-center gap-12 text-center md:text-left">
            <div className="flex-grow">
              <h3 className="text-3xl md:text-4xl font-bold mb-6 font-serif leading-tight">Besoin d'un diagnostic urgent ?</h3>
              <p className="text-emerald-200 mb-0 leading-relaxed">
                Nos équipes mobiles se déplacent également dans les zones rurales autour de Sakassou pour le dépistage précoce de l'ulcère de Buruli.
              </p>
            </div>
            <div className="flex-shrink-0 flex flex-col gap-4 w-full md:w-auto">
              <a href="tel:+22521010203" className="bg-white text-emerald-900 px-12 py-5 rounded-full font-bold text-lg hover:bg-emerald-50 transition-all text-center">
                Appel d'urgence
              </a>
              <span className="text-center text-xs text-emerald-500 font-bold uppercase tracking-widest">Disponible 24h/24</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
