
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  price: string;
}

export interface NewsItem {
  id: string;
  title: string;
  date: string;
  summary: string;
}

export interface Staff {
  name: string;
  role: string;
  bio: string;
  image: string;
  skills?: string[];
}

export type Permission = 
  | 'PATIENT_DATA' 
  | 'PHARMACY_STOCK' 
  | 'FINANCIALS' 
  | 'LAB_REPORTS' 
  | 'SURGERY_SCHEDULING'
  | 'COMMUNITY_OUTREACH'
  | 'ADMIN_ACCESS';

export interface StaffMember {
  id: string;
  name: string;
  role: StaffRole;
  status: 'ACTIF' | 'ATTENTE' | 'BLOQUÉ';
  permissions: Permission[];
}

// Rôles spécifiques à l'Hôpital de Sakassou
export type StaffRole = 
  | 'SURGERY'    // Chirurgie réparatrice
  | 'LAB'        // Laboratoire PCR/Bio
  | 'PHARMA'     // Pharmacie spécialisée
  | 'DATA'       // Gestionnaire de données OMS
  | 'CASHIER'    // Caisse sociale
  | 'IDE'        // Infirmier (Pansements/Soins)
  | 'SPECIALIST' // Infectiologue / MTN
  | 'HIV'        // Unité VIH
  | 'ADMIN'      // Direction / RH
  | 'GYNECO'     // Maternité
  | '';

export enum Page {
  Home = 'home',
  About = 'about',
  DiseaseInfo = 'disease',
  Services = 'services',
  Booking = 'booking',
  PatientPortal = 'portal',
  StaffPortal = 'staff'
}
