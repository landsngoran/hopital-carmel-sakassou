
export const translations = {
  fr: {
    nav: {
      home: "Accueil",
      about: "L'Hôpital",
      disease: "Ulcère de Buruli",
      services: "Services",
      booking: "RDV",
      staff: "Staff",
      portal: "Portail Patient"
    },
    hero: {
      title: "Guérir les plaies avec",
      titleAccent: "compassion",
      subtitle: "Le centre de référence pour le traitement de l'ulcère de Buruli, l'ophtalmologie et la cardiologie au cœur du pays Baoulé.",
      cta_rdv: "Prendre RDV",
      cta_info: "S'informer"
    },
    stats: {
      cures: "Guérisons / An",
      beds: "Lits Disponibles",
      emergency: "Urgences Ouvertes",
      dedication: "Dévouement"
    },
    footer: {
      mission: '"Soigner le corps, apaiser l\'âme." Missionnaire et dévoué à la santé communautaire en Côte d\'Ivoire.',
      quickLinks: "Accès Rapide",
      contact: "Contact Sakassou",
      location: "Localisation"
    }
  },
  en: {
    nav: {
      home: "Home",
      about: "Hospital",
      disease: "Buruli Ulcer",
      services: "Services",
      booking: "Booking",
      staff: "Staff",
      portal: "Patient Portal"
    },
    hero: {
      title: "Healing wounds with",
      titleAccent: "compassion",
      subtitle: "The reference center for Buruli ulcer treatment, ophthalmology, and cardiology in the heart of Baoulé country.",
      cta_rdv: "Book Appointment",
      cta_info: "Learn More"
    },
    stats: {
      cures: "Cures / Year",
      beds: "Available Beds",
      emergency: "24/7 Emergency",
      dedication: "Dedication"
    },
    footer: {
      mission: '"Healing the body, soothing the soul." Missionary and dedicated to community health in Ivory Coast.',
      quickLinks: "Quick Links",
      contact: "Contact Sakassou",
      location: "Location"
    }
  }
};
