
/**
 * ARCHITECTURE DE DONNÉES PERSISTANTE - LOCAL STORAGE ENGINE
 * Simule Supabase avec persistance locale pour l'Hôpital de Sakassou.
 * Gère les accréditations sécurisées et le suivi clinique.
 */

const DB_KEY = 'carmel_os_db';

const defaultDB = {
  security_vault: {
    'HIV-SEC-2024': 'UNITÉ VIH/ARV',
    'SURG-OP-99': 'BLOC CHIRURGIE',
    'LAB-BIO-44': 'LABORATOIRE',
    'IT-ROOT-01': 'SERVICE INFORMATIQUE'
  },
  staff_profiles: [
    { id: 'SAK-IT-01', name: 'Admin Système', role: 'ADMIN', points: 9999, status: 'ACTIF' },
    { id: 'SAK-HIV-01', name: 'Dr. Bamba', role: 'HIV', points: 2450, status: 'ACTIF' }
  ],
  viral_load_tracking: [
    { patient_id: 'ND-2055', date: '2023-11-12', value: 450000, unit: 'copies/ml', status: 'HAUT' },
    { patient_id: 'ND-2055', date: '2024-02-10', value: 20, unit: 'copies/ml', status: 'INDÉTECTABLE' }
  ],
  pharmacy_stock: [
    { id: 'p1', name: 'Rifampicine 300mg', stock: 1200, origin: 'DISTRICT', last_restock: '2024-03-01' },
    { id: 'p2', name: 'Clarithromycine', stock: 850, origin: 'CARMEL/DON', last_restock: '2024-02-15' },
    { id: 'p3', name: 'Tenofovir/Lamivudine', stock: 3000, origin: 'DISTRICT', last_restock: '2024-03-05' }
  ],
  patient_records: [
    { id: 'ND-1024', name: 'Amoin K.', location: 'Assandré', symptoms: 'Ulcère de Buruli stade 2' },
    { id: 'ND-2055', name: 'Yao J.', location: 'Sakassou', symptoms: 'Suivi ARV régulier' }
  ],
  patient_history: [
    { date: '2024-03-10', provider: 'Dr. Konan', title: 'Consultation Initiale', note: 'Patient présente un nodule suspect sur l\'avant-bras.' },
    { date: '2024-03-12', provider: 'Laboratoire', title: 'Analyse PCR', note: 'Mycobacterium ulcerans détecté. Début traitement Rifampicine.' }
  ],
  booking_messages: [
    { id: 'msg-1', name: 'Jean Kouassi', phone: '+225 01020304', subject: 'Urgence Buruli', message: 'Douleur intense au bras gauche.', date: '2024-03-14', status: 'NOUVEAU' }
  ]
};

// Initialisation de la DB
if (!localStorage.getItem(DB_KEY)) {
  localStorage.setItem(DB_KEY, JSON.stringify(defaultDB));
}

const getDB = () => JSON.parse(localStorage.getItem(DB_KEY) || '{}');
const saveDB = (db: any) => localStorage.setItem(DB_KEY, JSON.stringify(db));

export const supabase: any = {
  verifySiloCode: (code: string) => {
    const db = getDB();
    return db.security_vault[code] || null;
  },
  from: (table: string) => {
    const chain: any = {
      _filters: [] as any[],
      select: () => chain,
      eq: (col: string, val: any) => {
        chain._filters.push({ col, val });
        return chain;
      },
      insert: (record: any) => {
        const db = getDB();
        if (!db[table]) db[table] = [];
        db[table].push({ ...record, id: record.id || `rec-${Date.now()}`, date: record.date || new Date().toISOString().split('T')[0] });
        saveDB(db);
        return Promise.resolve({ data: record, error: null });
      },
      update: (updates: any) => {
        const db = getDB();
        if (db[table]) {
          db[table] = db[table].map((item: any) => {
            let match = true;
            chain._filters.forEach((f: any) => { if (item[f.col] !== f.val) match = false; });
            return match ? { ...item, ...updates } : item;
          });
          saveDB(db);
        }
        return Promise.resolve({ error: null });
      },
      then: (resolve: any) => {
        const db = getDB();
        let data = db[table] || [];
        chain._filters.forEach((f: any) => {
          data = data.filter((item: any) => item[f.col] === f.val);
        });
        return Promise.resolve({ data, error: null }).then(resolve);
      }
    };
    return chain;
  }
};
