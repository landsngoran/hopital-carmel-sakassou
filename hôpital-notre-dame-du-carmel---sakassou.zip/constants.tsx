
import React from 'react';
import { Service, Staff, NewsItem } from './types';

export const SERVICES: Service[] = [
  {
    id: 'general-consult',
    title: 'Consultation Générale',
    description: 'Soins de santé primaire et triage. Un tarif social pour garantir l\'accès à tous les habitants de Sakassou.',
    icon: '👨‍👩‍👧',
    price: '500 FCFA'
  },
  {
    id: 'hiv-unit',
    title: 'Unité VIH / ARV',
    description: 'Prise en charge globale, dépistage anonyme et distribution de traitements ARV. Accompagnement psychologique dédié.',
    icon: '🎗️',
    price: 'Gratuit'
  },
  {
    id: 'buruli-diag',
    title: 'Diagnostic Buruli',
    description: 'Dépistage expert et diagnostic précoce de l\'ulcère de Buruli. Entièrement gratuit pour tous.',
    icon: '🔍',
    price: 'Gratuit'
  },
  {
    id: 'gyneco',
    title: 'Gynécologie & Maternité',
    description: 'Suivi de grossesse, accouchements sécurisés et planning familial. Un pilier pour les femmes de Sakassou.',
    icon: '🤰',
    price: '2000 FCFA'
  },
  {
    id: 'surgery-recon',
    title: 'Chirurgie Reconstructive',
    description: 'Interventions spécialisées pour traiter les contractures et restaurer la mobilité des membres touchés.',
    icon: '🩹',
    price: 'Pris en charge'
  },
  {
    id: 'lab-specialized',
    title: 'Laboratoire de Biologie',
    description: 'Analyses PCR, biopsies et cultures bactériennes pour confirmer la présence de Mycobacterium ulcerans.',
    icon: '🔬',
    price: 'Gratuit (Buruli)'
  },
  {
    id: 'specialized-pharma',
    title: 'Pharmacie Spécialisée',
    description: 'Distribution contrôlée de Rifampicine et Clarithromycine. Gestion stricte des stocks pour éviter les ruptures.',
    icon: '💊',
    price: 'Gratuit'
  },
  {
    id: 'rehabilitation',
    title: 'Rééducation Physique',
    description: 'Physiothérapie et accompagnement pour prévenir les handicaps permanents après la guérison.',
    icon: '🚶',
    price: '500 FCFA / Séance'
  },
  {
    id: 'ophtalmo',
    title: 'Ophtalmologie',
    description: 'Examens de la vue complets et chirurgie de la cataracte pour les populations rurales.',
    icon: '👁️',
    price: '5000 FCFA'
  },
  {
    id: 'cardio',
    title: 'Cardiologie',
    description: 'Suivi cardiaque, ECG et gestion de l\'hypertension artérielle.',
    icon: '❤️',
    price: '10000 FCFA'
  }
];

export const TEAM: Staff[] = [
  {
    name: 'Dr. Konan Koffi',
    role: 'Directeur Médical',
    bio: 'Pionnier de la lutte contre le Buruli en Côte d\'Ivoire. Formé à l\'Institut Pasteur, il a choisi Sakassou pour son impact communautaire.',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=800',
    skills: ['Infectiologie', 'PCR Expert', 'Baoulé Natif']
  },
  {
    name: 'Dr. Jean-Baptiste Yao',
    role: 'Chirurgien Orthopédiste',
    bio: 'Expert en greffes de peau et chirurgie réparatrice. Il redonne l\'usage de leurs membres aux enfants de la région.',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=800',
    skills: ['Micro-chirurgie', 'Greffe', 'Traumatologie']
  },
  {
    name: 'Sœur Marie-Ange',
    role: 'Infirmière Major',
    bio: 'Depuis 15 ans au service des plus démunis. Elle coordonne les soins de plaies complexes et le soutien psychologique.',
    image: 'https://images.unsplash.com/photo-1559839734-2b71f1536783?auto=format&fit=crop&q=80&w=800',
    skills: ['Soins Plaies', 'Éthique', 'Dioula Expert']
  },
  {
    name: 'Mme Amoin Kouassi',
    role: 'Médiatrice Sociale',
    bio: 'Le lien entre l\'hôpital et les villages. Elle éduque les familles sur l\'hygiène et la détection précoce.',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=800',
    skills: ['Santé Rurale', 'Éducation', 'Langues Locales']
  },
  {
    name: 'M. Ibrahim Bamba',
    role: 'Responsable Pharmacie',
    bio: 'Garant de la disponibilité des antibiotiques critiques. Expert en logistique médicale en zone rurale.',
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=800',
    skills: ['Logistique', 'Antibio-thérapie', 'Gestion']
  },
  {
    name: 'Dr. Affoué Lou',
    role: 'Nutritionniste',
    bio: 'La nutrition est la clé de la guérison cutanée. Elle accompagne les patients pour booster leur système immunitaire.',
    image: 'https://images.unsplash.com/photo-1651008376811-b90baee60c1f?auto=format&fit=crop&q=80&w=800',
    skills: ['Diététique', 'Système Immunitaire', 'Pédiatrie']
  }
];

export const NEWS: NewsItem[] = [
  {
    id: '1',
    title: 'Mission Mobile à Assandré',
    date: '12 Mars 2024',
    summary: 'Dépistage précoce réussi pour 45 enfants dans le village d\'Assandré via notre unité mobile.'
  },
  {
    id: '2',
    title: 'Succès Chirurgical',
    date: '05 Fév. 2024',
    summary: 'Première greffe de peau réussie à Sakassou pour un patient atteint d\'une forme ulcérée géante.'
  }
];
